import { SanityClient } from "@sanity/client";

export default sanityClient({
  projectId: "609mkvpo",
  dataset: "production",
});
