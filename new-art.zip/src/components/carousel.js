import CarouselItems from "./carouselItems";
export default function Carousel() {
  return (
    <header className="slider">
      <CarouselItems />
    </header>
  );
}
